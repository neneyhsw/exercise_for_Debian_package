#!/bin/bash
#
# This script is a simple exercise to print some text on the terminal
#
# 04/29/2024

echo "this is a test from Yu-Hsin Wang" >&2

exit 0
